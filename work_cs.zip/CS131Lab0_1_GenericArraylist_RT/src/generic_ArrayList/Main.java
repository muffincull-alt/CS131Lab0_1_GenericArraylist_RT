package generic_ArrayList;

public class Main {
    public static void main(String[] args) {
        // Part 1: Test generic FirstList with integers
        FirstList<Integer> intList = new FirstList<>();
        for (int i = 0; i < 10; i++) intList.addItem(i);
        intList.addItem(6, 2); // add 6 at index 2
        intList.doubleListSize(); // show doubling

        System.out.println("Item number 3 is: " + intList.getItem(3) + " and should be a 6");
        System.out.println("The first four items in the list are:");
        for (int i = 0; i < 4; i++) System.out.print(intList.getItem(i) + " ");
        System.out.println("\n");

        // Part 2: Squares
        FirstList<Square> squareList = new FirstList<>();
        for (int i = 0; i < 20; i++) squareList.addItem(new Square(i));

        System.out.println("Squares:");
        System.out.println(squareList.getItem(1));
        System.out.println(squareList.getItem(15));

        // Points
        FirstList<PointThreeD> pointList = new FirstList<>();
        for (int i = 0; i < 20; i++) pointList.addItem(new PointThreeD(i, i, i));

        double distance = pointList.getItem(3).distanceTo(pointList.getItem(12));
        System.out.printf("Point Distance: %.2f\n\n", distance);

        // Part 3: ShapeList storing both Squares and Points
        FirstList<Object> shapeList = new FirstList<>();
        shapeList.addItem(new PointThreeD(2.0, 3.0, 5.0));
        shapeList.addItem(new Square(2.0));

        System.out.println("ShapeList contents:");
        System.out.println(shapeList.getItem(0));
        System.out.println(shapeList.getItem(1));
    }
}
