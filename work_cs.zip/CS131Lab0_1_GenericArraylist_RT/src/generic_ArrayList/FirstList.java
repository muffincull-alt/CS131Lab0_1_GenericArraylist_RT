package generic_ArrayList;

/**
 * Generic ArrayList implementation called FirstList.
 * @param <E> type of elements stored in the list
 */
public class FirstList<E> {
    private E[] ar;
    private int currentItem;

    @SuppressWarnings("unchecked")
    public FirstList() {
        ar = (E[]) new Object[10];
        currentItem = -1;
    }

    @SuppressWarnings("unchecked")
    public void doubleListSize() {
        E[] temp = (E[]) new Object[ar.length * 2];
        for (int i = 0; i <= currentItem; i++) {
            temp[i] = ar[i];
        }
        ar = temp;
        System.out.println("New Size is: " + ar.length);
    }

    public void addItem(E item) {
        if (currentItem == ar.length - 1) {
            doubleListSize();
        }
        currentItem++;
        ar[currentItem] = item;
    }

    public void addItem(E item, int index) {
        if (currentItem == ar.length - 1) {
            doubleListSize();
        }
        for (int i = currentItem; i >= index; i--) {
            ar[i + 1] = ar[i];
        }
        ar[index] = item;
        currentItem++;
    }

    public void deleteItem(int index) {
        if (index < 0 || index > currentItem) return;
        for (int i = index; i < currentItem; i++) {
            ar[i] = ar[i + 1];
        }
        ar[currentItem] = null;
        currentItem--;
    }

    public int getLength() {
        return currentItem + 1;
    }

    public E getItem(int index) {
        if (index < 0 || index > currentItem) return null;
        return ar[index];
    }
}

