package generic_ArrayList;

/**
 * Represents a point in 3D space.
 */
public class PointThreeD {
    private double xPoint;
    private double yPoint;
    private double zPoint;

    public PointThreeD() {
        xPoint = yPoint = zPoint = 0.0;
    }

    public PointThreeD(double x, double y, double z) {
        xPoint = x;
        yPoint = y;
        zPoint = z;
    }

    public double getxPoint() { return xPoint; }
    public double getyPoint() { return yPoint; }
    public double getzPoint() { return zPoint; }

    public void setxPoint(double xPoint) { this.xPoint = xPoint; }
    public void setyPoint(double yPoint) { this.yPoint = yPoint; }
    public void setzPoint(double zPoint) { this.zPoint = zPoint; }

    public double distanceTo(PointThreeD other) {
        return Math.sqrt(Math.pow(this.xPoint - other.xPoint, 2)
                + Math.pow(this.yPoint - other.yPoint, 2)
                + Math.pow(this.zPoint - other.zPoint, 2));
    }

    @Override
    public String toString() {
        return "PointThreeD [xPoint=" + xPoint + ", yPoint=" + yPoint + ", zPoint=" + zPoint + "]";
    }
}

